A Pen created at CodePen.io. You can find this one at https://codepen.io/anon/pen/GpNbVd.

 A design for a sign-up/login form using tabs and floating form labels.

Forked from [Eric](http://codepen.io/ehermanson/)'s Pen [Sign-Up/Login Form](http://codepen.io/ehermanson/pen/KwKWEv/).